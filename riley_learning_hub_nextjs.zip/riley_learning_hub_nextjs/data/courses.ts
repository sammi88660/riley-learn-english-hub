export type ReadingItem={en:string;zh:string;icon?:string}
export type Vocab={word:string;pos?:string;zh:string;examples:{en:string;zh:string}[];collocations?:string[];note?:string}
export type Lesson={id:string;title:string;subtitle?:string;readings:ReadingItem[];dialogue?:ReadingItem[];vocab:Vocab[];grammar:{title:string;formula?:string;ex:string;zh:string;note?:string}[]}
export type Course={id:string;name:string;icon:string;lessons:Lesson[]}
export const courses:Course[]=[
{id:'speaking',name:'週四口說課',icon:'🎙️',lessons:[]},
{id:'cloud',name:'雲課程',icon:'☁️',lessons:[]},
{id:'toeic',name:'TOEIC課程',icon:'🎯',lessons:[
{id:'toeic-1',title:'TOEIC Course 1｜Lesson 1: Picture yourself in the scenario!',subtitle:'Part 1 圖片描述：倉庫、包裹、人物動作',readings:[
{icon:'📦',en:'An employee is checking the inventory.',zh:'一名員工正在檢查庫存。'},
{icon:'🏬',en:'A guy is checking the packages on racks.',zh:'一名男子正在檢查架上的包裹。'},
{icon:'🚶',en:'He is walking along a corridor in a warehouse.',zh:'他正沿著倉庫走廊行走。'},
{icon:'🚜',en:'A worker driving a forklift is restocking in a warehouse.',zh:'一名駕駛堆高機的工人正在倉庫補貨。'},
{icon:'📋',en:'Two workers are taking inventories.',zh:'兩名工人正在盤點庫存。'},
{icon:'💬',en:'Participants are chatting with each other in small groups.',zh:'與會者正在小組中彼此交談。'}],vocab:[
{word:'inventory',pos:'n.',zh:'庫存；盤點',examples:[{en:'An employee is checking the inventory.',zh:'一名員工正在檢查庫存。'},{en:'We need to take inventory every month.',zh:'我們每個月都需要盤點庫存。'}],collocations:['check inventory','take inventory','inventory list']},
{word:'warehouse',pos:'n.',zh:'倉庫',examples:[{en:'He is working in a warehouse.',zh:'他在倉庫工作。'},{en:'The packages are stored in a warehouse.',zh:'包裹被存放在倉庫裡。'}],collocations:['warehouse worker','warehouse rack']},
{word:'forklift',pos:'n.',zh:'堆高機',examples:[{en:'A worker is driving a forklift.',zh:'一名工人正在開堆高機。'},{en:'Forklifts are used to move heavy products.',zh:'堆高機用來移動重物。'}]},
{word:'rack',pos:'n.',zh:'架子',examples:[{en:'The boxes are on the racks.',zh:'箱子在架子上。'},{en:'He is checking packages on racks.',zh:'他正在檢查架上的包裹。'}]},
{word:'seal',pos:'v.',zh:'封口；密封',examples:[{en:'A guy is sealing an envelope.',zh:'一名男子正在封信封。'},{en:'Please seal the package before shipping it.',zh:'寄送前請先把包裹封好。'}]}
],grammar:[{title:'現在進行式描述圖片',formula:'be + V-ing',ex:'A man is working in a warehouse.',zh:'一名男子正在倉庫工作。',note:'TOEIC Part 1 常用現在進行式描述照片中正在發生的動作。'}]},
{id:'toeic-2',title:'TOEIC Course 2｜Lesson 2: Aim for “functional” terms!',subtitle:'閱讀與功能性詞彙：agenda、budget、fanboys、子句拆解',readings:[
{icon:'🚢',en:'Chinese exports of rare earth minerals, which are crucial for modern technology, were high on the agenda of the meetings.',zh:'中國稀土礦物的出口，對現代科技至關重要，是這些會議的重要議題。'},
{icon:'📝',en:'“Prioritized as the most important item.”',zh:'「被優先列為最重要的項目。」'},
{icon:'✅',en:'Related vocabulary: to-do list or checklist.',zh:'相關詞彙：待辦清單或檢查清單。'},
{icon:'🙋',en:'To sum up: “to cut a long story short.”',zh:'總結來說：「長話短說。」'},
{icon:'💵',en:'To gross means to earn.',zh:'gross 作動詞時可以表示賺取、總收入。'},
{icon:'📒',en:'Net worth means the total value of what someone owns after debts are subtracted.',zh:'net worth 指扣除債務後的淨資產。'},
{icon:'🧱',en:'“result(ed) in” means cause.',zh:'result(ed) in 表示導致、造成。'},
{icon:'🥤',en:'Fizzy, quenching summer drinks.',zh:'有氣泡的、解渴的夏日飲品。'},
{icon:'🍗',en:'Crispy and crunchy describe food textures.',zh:'crispy 和 crunchy 都可以形容食物口感酥脆、脆脆的。'},
{icon:'👛',en:'We are on a thin or tight budget this quarter.',zh:'我們這一季的預算很緊。'}],vocab:[
{word:'agenda',pos:'n.',zh:'議程；待討論事項',examples:[{en:'Rare earth exports were high on the agenda.',zh:'稀土出口是議程上的重要項目。'},{en:'What is on the agenda today?',zh:'今天議程上有什麼？'}],collocations:['on the agenda','high on the agenda']},
{word:'crucial',pos:'adj.',zh:'至關重要的',examples:[{en:'Rare earth minerals are crucial for modern technology.',zh:'稀土礦物對現代科技至關重要。'},{en:'Sleep is crucial for learning.',zh:'睡眠對學習很重要。'}]},
{word:'to sum up',pos:'phr.',zh:'總結來說',examples:[{en:'To sum up, we need more practice.',zh:'總結來說，我們需要更多練習。'},{en:'To cut a long story short, I changed my plan.',zh:'長話短說，我改變了計畫。'}]},
{word:'gross',pos:'v.',zh:'賺得；總收入為',examples:[{en:'The movie grossed millions of dollars.',zh:'這部電影總收入達數百萬美元。'},{en:'The company grossed more than expected.',zh:'公司總收入比預期多。'}]},
{word:'net worth',pos:'n.',zh:'淨值；淨資產',examples:[{en:'His net worth increased this year.',zh:'他的淨資產今年增加了。'},{en:'Net worth is different from income.',zh:'淨資產和收入不同。'}]},
{word:'fizzy',pos:'adj.',zh:'有氣泡的',examples:[{en:'I like fizzy drinks in summer.',zh:'我夏天喜歡喝氣泡飲。'},{en:'This soda is too fizzy for me.',zh:'這瓶汽水對我來說氣太多了。'}]},
{word:'crispy',pos:'adj.',zh:'酥脆的',examples:[{en:'The fried chicken is crispy.',zh:'炸雞很酥脆。'},{en:'I like crispy fries.',zh:'我喜歡酥脆的薯條。'}]},
{word:'crunchy',pos:'adj.',zh:'脆脆的',examples:[{en:'These chips are crunchy.',zh:'這些洋芋片很脆。'},{en:'The salad has a crunchy texture.',zh:'沙拉有脆脆的口感。'}]},
{word:'tight budget',pos:'n.',zh:'緊縮的預算',examples:[{en:'We are on a tight budget this quarter.',zh:'我們這一季預算很緊。'},{en:'I need to save money because I am on a tight budget.',zh:'因為預算很緊，我需要省錢。'}]},
{word:'discreet',pos:'adj.',zh:'低調的；謹慎的',examples:[{en:'Let’s track our expenses in a more discreet way.',zh:'我們用更低調的方式追蹤支出吧。'},{en:'Please be discreet about this issue.',zh:'這件事請低調處理。'}]}
],grammar:[
{title:'as / since 表示原因',formula:'As/Since + 已知原因, 主句',ex:'Since I missed my lunch time, I wanted to eat something first.',zh:'因為我錯過午餐時間，所以我想先吃點東西。',note:'as 和 since 的原因通常是對方已知或容易理解的背景。'},
{title:'because 表示原因',formula:'主句 + because + 新資訊原因',ex:'I stayed home because I was sick.',zh:'我待在家，因為我生病了。',note:'because 常用來回答原因，對方會期待得到解釋。'},
{title:'關係子句補充名詞',formula:'Noun + who/which + clause',ex:'My dog, who usually refuses to go near the water, dived in the canal.',zh:'我的狗平常不願靠近水，卻跳進運河裡。'}]}]},
{id:'mystery',name:'怪奇檔案事件',icon:'📁',lessons:[]},
{id:'lifestyle',name:'生活美學課',icon:'🌿',lessons:[
{id:'life-w6',title:'Week 6｜Japan × Greece',subtitle:'旅行與生活品味：從文化中看見美',readings:[{icon:'👘',en:'Wearing a Kimono is a beautiful tradition in Japan.',zh:'穿著和服是日本一項美麗的傳統。'},{icon:'🌅',en:'Santorini is famous for its blue-domed churches and the world’s most beautiful sunset in Oia.',zh:'聖托里尼以藍頂教堂與伊亞世界聞名的美麗夕陽著稱。'}],vocab:[],grammar:[]},
{id:'life-w7',title:'Week 7｜Digital Detox',subtitle:'數位減壓：找回生活的平衡',readings:[{icon:'📱',en:"In today's hyper-connected world, we are constantly bombarded by digital stimuli.",zh:'在今日高度連結的世界裡，我們不斷受到數位刺激轟炸。'},{icon:'🌿',en:"It’s time to unplug and recharge our souls.",zh:'是時候放下電子產品，重新為心靈充電了。'}],dialogue:[{en:'Mark: Hey Sophie, did you see the cat meme I tagged you in last night?',zh:'Mark：嘿 Sophie，你有看到我昨晚標記你的貓咪迷因嗎？'},{en:'Sophie: Sorry, Mark! I’ve actually started a digital detox.',zh:'Sophie：抱歉 Mark！其實我開始數位排毒了。'}],vocab:[],grammar:[]}
]}]
