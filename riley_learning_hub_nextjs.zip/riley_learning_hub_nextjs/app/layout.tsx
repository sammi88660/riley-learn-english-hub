import './globals.css'
export const metadata={title:"Riley's English Learning Hub",description:'Personal English learning hub'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-Hant"><body>{children}</body></html>}
