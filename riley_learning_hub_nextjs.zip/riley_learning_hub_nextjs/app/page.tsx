'use client'
import {useMemo,useState} from 'react'
import {courses} from '../data/courses'

export default function Page(){
  const [courseId,setCourseId]=useState('toeic')
  const course=useMemo(()=>courses.find(c=>c.id===courseId)!,[courseId])
  const [lessonId,setLessonId]=useState(course.lessons[0]?.id||'')
  const lesson=course.lessons.find(l=>l.id===lessonId)||course.lessons[0]
  function selectCourse(id:string){setCourseId(id); const c=courses.find(x=>x.id===id)!; setLessonId(c.lessons[0]?.id||'')}
  return <>
    <header className="top"><div className="brand">📖 Riley’s English Learning Hub</div><div className="tagline">專注學習・每天進步！ ♡</div></header>
    <main className="wrap">
      <div className="courseTabs">{courses.map(c=><button key={c.id} onClick={()=>selectCourse(c.id)} className={`tab ${courseId===c.id?'active':''}`}>{c.icon}　{c.name}</button>)}</div>
      <div className="layout">
        <aside className="sidebar">
          <div className="back">← English 專屬網站</div>
          <div className="sideTitle">{course.name} 列表</div>
          {course.lessons.length?course.lessons.map(l=><button key={l.id} onClick={()=>setLessonId(l.id)} className={`lessonBtn ${lesson?.id===l.id?'active':''}`}>{l.title.replace('TOEIC ','').replace('Week ','W')}</button>):<div className="empty">這個分類之後新增課程</div>}
        </aside>
        <section className="main">
          {lesson?<LessonView lesson={lesson}/>:<div className="empty"><h1>{course.name}</h1><p>之後可以把這個課程的每週主題放在這裡。</p></div>}
        </section>
      </div>
    </main>
  </>
}
function LessonView({lesson}:any){
 const letters=Array.from(new Set((lesson.vocab||[]).map((v:any)=>v.word[0].toUpperCase()))).sort()
 return <>
   <h1>{lesson.title}</h1>
   {lesson.subtitle&&<p style={{color:'#667085',fontWeight:700}}>{lesson.subtitle}</p>}
   <div className="section"><h2>📖 文章學習｜逐句中英對照</h2>{lesson.readings.map((r:any,i:number)=><ReadingRow key={i} item={r} i={i}/>)}</div>
   {lesson.dialogue?.length>0&&<div className="section"><h2>💬 人物對話｜逐句中英對照</h2>{lesson.dialogue.map((r:any,i:number)=><ReadingRow key={i} item={{...r,icon:'💬'}} i={i}/>)}</div>}
   {lesson.vocab?.length>0&&<div className="section"><h2>📚 Vocabulary 單字區塊</h2><div className="navSmall">{letters.map(l=><span className="anchor" key={l}>{l}</span>)}</div><div className="vocabGrid">{lesson.vocab.map((v:any)=><VocabCard key={v.word} v={v}/>)}</div></div>}
   {lesson.grammar?.length>0&&<div className="section"><h2>✨ Grammar 文法補充</h2><div className="grammar">{lesson.grammar.map((g:any)=><div className="card" key={g.title}><div className="word">{g.title}</div>{g.formula&&<div className="formula">{g.formula}</div>}<div className="example"><b>{g.ex}</b><br/>{g.zh}</div>{g.note&&<p style={{color:'#667085'}}>{g.note}</p>}</div>)}</div></div>}
 </>
}
function ReadingRow({item,i}:any){return <div className="readingRow"><div className="num">{i+1}</div><div className="thumb">{item.icon||'🖼️'}</div><div><div className="en">{item.en}</div><div className="zh">{item.zh}</div></div></div>}
function VocabCard({v}:any){return <div className="card"><div className="word">{v.word} <span className="pos">{v.pos}</span></div><p><b>中文：</b>{v.zh}</p>{v.examples.map((e:any,idx:number)=><div className="example" key={idx}>{e.en}<br/><span>{e.zh}</span></div>)}{v.collocations?.length>0&&<div style={{marginTop:10}}>{v.collocations.map((c:string)=><span className="pill" key={c}>{c}</span>)}</div>}{v.note&&<p style={{color:'#667085'}}>{v.note}</p>}</div>}
